package model;

public class B2C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
